module.exports=[78320,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_societies_page_actions_03vd9g0ntygu8.js.map