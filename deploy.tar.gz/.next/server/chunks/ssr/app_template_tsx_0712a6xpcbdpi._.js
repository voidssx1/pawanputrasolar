module.exports=[28997,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)("div",{className:"route-fade",children:a})}])},5381,function(a){a.n(a.i(28997))}];

//# sourceMappingURL=app_template_tsx_0712a6xpcbdpi._.js.map