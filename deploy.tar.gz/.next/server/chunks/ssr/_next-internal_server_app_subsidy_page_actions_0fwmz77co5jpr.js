module.exports=[69439,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_subsidy_page_actions_0fwmz77co5jpr.js.map