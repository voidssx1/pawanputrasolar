var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/[root-of-the-server]__0p7jkd4y9hjfk._.js")
R.c("server/chunks/_next-internal_server_app_api_leads_route_actions_10t572w3uu9xy.js")
R.m(747)
module.exports=R.m(747).exports
