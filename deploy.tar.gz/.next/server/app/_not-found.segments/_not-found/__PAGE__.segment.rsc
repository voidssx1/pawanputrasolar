2:"$Sreact.fragment"
3:"/_next/static/chunks/2950lkd8kij9b.js"
4:"/_next/static/chunks/2w7f3vx24ctoc.js"
5:"/_next/static/chunks/41tq-ytw3-7i9.js"
6:I[39756,["$3","$4","$5"],"default"]
7:I[37457,["$3","$4","$5"],"default"]
c:I[22016,["$3","$4","$5"],""]
d:I[97367,["$3","$4","$5"],"OutletBoundary"]
e:"$Sreact.suspense"
11:"ViewportBoundary"
12:I[97367,["$3","$4","$5"],"$11"]
13:"MetadataBoundary"
14:I[97367,["$3","$4","$5"],"$13"]
15:I[27201,["$3","$4","$5"],"IconMark"]
9:X
9:C
a:X
b:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$2","c",{"children":[["$","section",null,{"className":"section","style":{"paddingTop":"calc(var(--head-h) + 90px)","minHeight":"80svh"},"children":["$","div",null,{"className":"container","children":[["$","p",null,{"className":"eyebrow","children":"404 — Off the roof"}],["$","h1",null,{"style":{"fontSize":"clamp(3.5rem, 10vw, 9rem)","margin":"18px 0 22px","lineHeight":0.92},"children":["This page",["$","br",null,{}],["$","em",null,{"className":"serif forest","children":"caught no sun."}]]}],["$","p",null,{"className":"lede","style":{"marginBottom":28},"children":"The address does not exist, or it has moved. Head back to the home page, or call us and we will point you in the right direction."}],["$","div",null,{"style":{"display":"flex","gap":12,"flexWrap":"wrap"},"children":[["$","$Lc",null,{"className":"btn","href":"/","children":["Back to home",["$","svg",null,{"width":18,"height":18,"viewBox":"0 0 24 24","fill":"none","stroke":"currentColor","strokeWidth":1.6,"strokeLinecap":"round","strokeLinejoin":"round","aria-hidden":true,"children":["$","path",null,{"d":"M7 17 17 7M8 7h9v9"}]}]]}],["$","$Lc",null,{"className":"btn btn--line","href":"/contact","children":"Contact us"}]]}]]}]}],null,["$","$Ld",null,{"children":["$","$e",null,{"name":"Next.MetadataOutlet","children":"$@f"}]}]]}],"p":"$@10","v":null,"s":"$a"}}]]
1:[["children",{"s":"/_not-found","h":64,"d":{"r":["$","$2","c",{"children":[null,["$","$L6",null,{"parallelRouterKey":"children","template":["$","$L7",null,{}]}]]}],"p":"$@8","v":"$9","s":"$a"},"c":"$Qb"}]]
0:{"t":{"t":{"s":"","h":16,"c":"$Q1"},"h":{"r":["$","$2","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L12",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#ffffff"}],["$","meta","3",{"name":"color-scheme","content":"light"}]]}],["$","$L14",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$e",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Pawanputra Solar Solutions — Rooftop Solar, Delhi NCR"}],["$","meta","1",{"name":"description","content":"Premium rooftop solar for homes, businesses and housing societies across Delhi NCR. Engineered systems, subsidy paperwork handled, installation in 4–6 weeks."}],["$","meta","2",{"name":"application-name","content":"Pawanputra Solar Solutions"}],["$","meta","3",{"name":"keywords","content":"rooftop solar Delhi,solar panel installation Delhi NCR,PM Surya Ghar subsidy,home solar Noida,commercial solar Gurugram,housing society solar"}],["$","meta","4",{"name":"robots","content":"index, follow"}],["$","meta","5",{"property":"og:title","content":"Pawanputra Solar Solutions — Rooftop Solar, Delhi NCR"}],["$","meta","6",{"property":"og:description","content":"Premium rooftop solar for homes, businesses and housing societies across Delhi NCR. Engineered systems, subsidy paperwork handled, installation in 4–6 weeks."}],["$","meta","7",{"property":"og:url","content":"https://pawanputrasolar.digiedgeindia.com"}],["$","meta","8",{"property":"og:site_name","content":"Pawanputra Solar Solutions Pvt. Ltd."}],["$","meta","9",{"property":"og:locale","content":"en_IN"}],["$","meta","10",{"property":"og:image","content":"https://pawanputrasolar.digiedgeindia.com/images/hero-rooftop-wide.webp"}],["$","meta","11",{"property":"og:image:width","content":"1536"}],["$","meta","12",{"property":"og:image:height","content":"1024"}],["$","meta","13",{"property":"og:image:alt","content":"Rooftop solar array on a Delhi home at golden hour"}],["$","meta","14",{"property":"og:type","content":"website"}],["$","meta","15",{"name":"twitter:card","content":"summary_large_image"}],["$","meta","16",{"name":"twitter:title","content":"Pawanputra Solar Solutions — Rooftop Solar, Delhi NCR"}],["$","meta","17",{"name":"twitter:description","content":"Premium rooftop solar for homes, businesses and housing societies across Delhi NCR. Engineered systems, subsidy paperwork handled, installation in 4–6 weeks."}],["$","meta","18",{"name":"twitter:image","content":"https://pawanputrasolar.digiedgeindia.com/images/hero-rooftop-wide.webp"}],["$","link","19",{"rel":"icon","href":"/favicon.png"}],["$","link","20",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png"}],["$","$L15","21",{}]]}]}],null]}],null]}],"p":"$@16","v":null,"s":"$a"}},"a":"$@17","u":"$@18","b":"YejIgaTdDR5j8FIdc_1qU"}
f:null
18:true
a:300
a:C
17:0
8:"$undefined"
16:"$undefined"
10:"$undefined"
