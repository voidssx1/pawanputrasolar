:HL["/_next/static/chunks/3etc0lbyiax2t.css","style"]
:HL["/fonts/fonts.css","style"]
:HL["/fonts/poppins-700-latin.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/fonts/dmsans-latin.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
1:[["children",{"s":"__PAGE__","h":128}]]
0:{"b":"YejIgaTdDR5j8FIdc_1qU","t":{"t":{"s":"","h":16,"c":"$Q1"}}}
