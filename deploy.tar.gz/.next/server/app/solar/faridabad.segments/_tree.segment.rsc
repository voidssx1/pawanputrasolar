:HL["/_next/static/chunks/3etc0lbyiax2t.css","style"]
:HL["/fonts/fonts.css","style"]
:HL["/fonts/poppins-700-latin.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/fonts/dmsans-latin.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":{"n":"city","t":"d","k":"faridabad","s":[]},"h":65632,"c":"$Q3"}]]
1:[["children",{"s":"solar","h":131136,"c":"$Q2"}]]
0:{"b":"YejIgaTdDR5j8FIdc_1qU","t":{"t":{"s":"","h":131088,"c":"$Q1"}}}
