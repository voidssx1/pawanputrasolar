globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/YejIgaTdDR5j8FIdc_1qU/_buildManifest.js",
    "static/YejIgaTdDR5j8FIdc_1qU/_ssgManifest.js",
    "static/YejIgaTdDR5j8FIdc_1qU/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1pcw6gskne7pf.js",
    "static/chunks/0li7vzj18bfpo.js",
    "static/chunks/3jn_x8ihwq16e.js",
    "static/chunks/0iumlkwknlbd6.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/calculator/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/commercial/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/guides/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/guides/[slug]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/process/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/projects/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/quote/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/residential/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/societies/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/solar/[city]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/subsidy/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/systems/[slug]/page": {
      "otherChunks": [
        "static/chunks/1pcw6gskne7pf.js",
        "static/chunks/0li7vzj18bfpo.js",
        "static/chunks/3jn_x8ihwq16e.js",
        "static/chunks/0iumlkwknlbd6.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
